using System.Runtime.InteropServices;

[assembly: ComVisible(false)]
[assembly: Guid("70a33fa7-9f81-418d-bb25-6a4be6648ae4")]
[assembly: System.Reflection.AssemblyVersion("5.0.0.0")]
