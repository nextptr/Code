﻿namespace ServiceStack.Common.Tests.Models
{
    public class Poco
    {
        public string Name { get; set; }
    }
}