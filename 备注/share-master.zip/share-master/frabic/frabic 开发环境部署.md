# frabic 开发环境部署
这里以最新版本1.4为例

## 环境准备
 * [准备工作](https://hyperledger-fabric.readthedocs.io/en/latest/prereqs.html)
  
 * ubuntu 16.04 操作系统
 
 * go 1.11.x 版本以上
 
 * git 
 
 * [docker && docker-compose](https://hyperledger-fabric.readthedocs.io/en/latest/prereqs.html#docker-and-docker-compose)
 

 
 
