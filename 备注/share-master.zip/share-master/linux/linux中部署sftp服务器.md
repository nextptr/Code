# linux中部署sftp服务器

[linux下sftp服务搭建](https://www.jianshu.com/p/a9b7dab956c2)
