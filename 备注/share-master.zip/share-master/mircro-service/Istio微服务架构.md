# Istio 微服务架构

k8s && Istio

[Istio微服务架构实践](https://www.cnblogs.com/ericnie/p/7919017.html)
