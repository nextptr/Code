
# git 使用小结

## 前言：
 好多人包括我自己，对git只是停留在简单的诸如pull,push,add,commit 之类的操作，真正遇到问题时，需要复杂的操作，还是要重新谷歌或者百度一下
 今天就花点时间来总结一下,git的一些基本操作。
 
 [git远程仓库的使用](https://git-scm.com/book/zh/v2/Git-%E5%9F%BA%E7%A1%80-%E8%BF%9C%E7%A8%8B%E4%BB%93%E5%BA%93%E7%9A%84%E4%BD%BF%E7%94%A8)
